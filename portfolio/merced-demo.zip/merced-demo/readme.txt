Merced free bootstrap template

Merced is a one page multiuse template based on Bootstrap 3 Framework.
You can use it for whatever you want.

If you like the template, please spread the word.

theme version: 1.0
Release Date: 29 feb 2016
Author: jaime alejandro rios(http://jaiimeriios.com/)
Contact: jaimerios1989@gmail.com


:D


Credits: -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Demo Images
Author's. I took the pictures on a trip I took to Yosemite national park.

Fonts
Font Awesome by Dave Gandy - http://fortawesome.github.io/Font-Awesome/
Google Fonts - http://www.google.com/fonts

Resources
Bootstrap - http://getbootstrap.com/
jQuery - https://jquery.org/
Modernizr - http://modernizr.com/
Animate CSS - http://daneden.github.io/animate.css/
