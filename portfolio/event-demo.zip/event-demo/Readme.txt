Event free bootstrap template - Thanks for downloading this theme!

Event is a one page multiuse template based on the Bootstrap 4 Framework.
You can use it for whatever you want.
If you like the template, please spread the word.

Theme version: 1.0
Release Date: November 2018
Author: jaime alejandro rios(http://jaiimeriios.com/)
Contact: jaimerios1989@gmail.com

:D

Credits: -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Demo Images
Unsplash - https://unsplash.com

Fonts
Font Awesome - http://fortawesome.github.io/Font-Awesome/
Google Fonts - http://www.google.com/fonts

Resources
Animate CSS - http://daneden.github.io/animate.css/
Bootstrap - http://getbootstrap.com/
Easing - https://jqueryui.com/easing/
Font Awesome https://fontawesome.com/
jQuery - https://jquery.org/
OwlCarousel - https://owlcarousel2.github.io/OwlCarousel2/
Superfish - https://superfish.joelbirch.co/
Venobox - http://veno.es/venobox/
WowJs - https://wowjs.uk
